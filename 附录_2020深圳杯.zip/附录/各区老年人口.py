#!/usr/bin/env python
# coding: utf-8

# In[4]:


from pyecharts import options as opts
from pyecharts.charts import Map
# from pyecharts.charts.faker import Faker
# help(Map)
q= ["罗湖区","福田区","南山区","宝安区","龙岗区","盐田区","龙华区","坪山区","光明区","大鹏新区","深汕合作区"]
rk_value = [6.551,10.292,9.41,20.519,15.034,1.525,10.539,2.812,3.938,0.964,0.473]

def map_cq():
    c = (
        Map().add("", [list(z) for z in zip(q, rk_value)], "深圳",is_map_symbol_show=True,)
        .set_series_opts(label_opts=opts.LabelOpts(is_show=True,position='bottom', font_size=20,color= '#000000',
            font_style = 'italic' , font_weight = None,font_family = None,margin = 20))
        

        .set_global_opts(
            title_opts=opts.TitleOpts(title="深圳市各区老年人口(万人)数分布图",pos_top=True),
             visualmap_opts=opts.VisualMapOpts(is_piecewise=True, pieces=[
        {'min':0,'max': 3, 'label': '0-3', 'color': '#50A3BA'},
        {'min':3, 'max': 6, 'label': '3-6', 'color': '#B2D235'},
        {'min': 6, 'max': 9, 'label': '6-9', 'color': '#843900'},
        {'min': 9, 'max':12, 'label': '9-12', 'color': '#E2C568'},
        {'min': 12, 'max':15, 'label': '12-15', 'color': '#FCF84D'},
        {'min': 15, 'max': 18, 'label': '15-18', 'color': '#4172B8'},
        {'min': 18, 'label': '18以上', 'color': '#D71345'}  ],pos_left=True),
            
    ))     
    return c
if __name__ == '__main__':
    cq = map_cq()
    cq.render('E:/深圳杯/数据/深圳各区老年人口.html')


# In[ ]:





# In[ ]:




