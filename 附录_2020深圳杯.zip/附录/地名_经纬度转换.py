#!/usr/bin/env python
# coding: utf-8
import pandas as pd
import json
import requests

#获取经纬度
def getlnglat(address): #从本地的xlsx文件中获取商圈名称，作为此函数的实参
    output = 'json'
    ak ="SscuNBCvbs4F1v729osRHiiGcfuP4icd"  # 百度地图密钥ak,“控制台”-“应用管理”-“我的应用”-“创建应用”-“命名、*”提交后会生成AK
    url = 'http://api.map.baidu.com/geocoding/v3/?address={0}&output={1}&ak={2}'.format(address,output,ak)
    # print(url)
    html = requests.get(url=url)
    html = html.text
    temp = json.loads(html, strict=False)

    lat = temp['result']['location']['lat']
    lng = temp['result']['location']['lng']
    #
    return lat, lng                                     #纬度 latitude,经度 longitude

# def re_html(data):  #生成HTML适配的格式
#     data_html = pd.DataFrame(columns=['content'])        #建立一个列名为content的dataframe对象
#
#     for indexs in data.index:  #重新整理成html里适配的格式
#         data_html.loc[indexs, 'content'] = '{' +                                            '"lat":' + str(data.loc[indexs, '纬度']) + ',' +                                            '"lng":' + str(data.loc[indexs, '经度']) + ',' +                                            '"address":' + '"' + str(data.loc[indexs, 'MC']) + '"' +                                            '}' + ','
#     data_html.to_csv("E:/深圳杯/数据/深圳市医院地址_经纬度.csv", encoding="gbk")     #相对路径，生成了该csv文件

if __name__ == '__main__':
    data = pd.read_excel('E:/深圳杯/数据/address.xlsx')
    # lat_=[]
    # lng_=[]
    for index in data.index:                             #index为data的序号，从0开始
        get_location = getlnglat(data.loc[index, 'MC'])  #通过序号进行索引，获得MC列下对应的地址名称
        lat = get_location[0]
        lng = get_location[1]
        data.loc[index, '纬度'] = lat
        data.loc[index, '经度'] = lng
        # lat_.append(lat)
        # lng_.append(lng)
    # data["lng"]=lng_
    # data["lat"]=lat_
    data.to_csv("E:/深圳杯/数据/深圳市医院地址_经纬度.csv")
    # re_html(data)


# In[ ]:





# In[ ]:




