#!/usr/bin/env python
# coding: utf-8

# In[31]:


from pyecharts import options as opts
from pyecharts.charts import Map
# from pyecharts.charts.faker import Faker
# help(Map)
q= ["福田区","罗湖区","南山区","盐田区","宝安区","龙华区","光明区","龙岗区","坪山区","大鹏新区"]
rk_value = [163.37,103.99,24.29,149.36,325.78,238.64,167.28,44.63,62.5,15.3,7.51]

def map_cq():
    c = (
        Map().add("", [list(z) for z in zip(q, rk_value)], "深圳",is_map_symbol_show=True,)
        .set_series_opts(label_opts=opts.LabelOpts(is_show=True,position='bottom', font_size=10,color= '#000000',
            font_style = 'italic' , font_weight = None,font_family = None,margin = 20))
        

        .set_global_opts(
            title_opts=opts.TitleOpts(title="深圳市各区人口数分布图",pos_top=True),
             visualmap_opts=opts.VisualMapOpts(is_piecewise=True, pieces=[
        {'min':0,'max': 50, 'label': '0-50', 'color': '#50A3BA'},
        {'min':50, 'max': 100, 'label': '50-100', 'color': '#B2D235'},
        {'min': 100, 'max': 150, 'label': '100-150', 'color': '#843900'},
        {'min': 150, 'max':200, 'label': '150-200', 'color': '#E2C568'},
        {'min': 200, 'max':250, 'label': '200-250', 'color': '#FCF84D'},
        {'min': 250, 'max': 300, 'label': '250-300', 'color': '#4172B8'},
        {'min': 300, 'label': '300以上', 'color': '#D71345'}  ],pos_left=True),
            
    ))     
    return c
if __name__ == '__main__':
    cq = map_cq()
    cq.render('E:/深圳杯/数据/深圳各区人口.html')


# In[ ]:





# In[ ]:




